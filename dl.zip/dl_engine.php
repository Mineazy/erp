<?php
set_time_limit(60);
$dir = __DIR__;
$engineDir = "$dir/node_modules/.prisma/client";
$commit = '605197351a3c8bdd595af2d2a9bc3025bca48ea2';
$version = '5.22.0-44.605197351a3c8bdd595af2d2a9bc3025bca48ea2';

// For OpenSSL 1.1.x
$platform = 'linux-openssl-1.1.x';
$binary = 'libquery_engine.so.node';

$url = "https://binaries.prisma.sh/all_commits/$version/$commit/$platform/$binary.gz";
echo "URL: $url\n";

echo "Downloading engine...\n";
$gzFile = "$engineDir/$binary.gz";
$ch = curl_init($url);
$fp = fopen($gzFile, 'w');
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
fclose($fp);

echo "HTTP: $httpCode, Size: " . filesize($gzFile) . "\n";

if ($httpCode == 200 && filesize($gzFile) > 100) {
    echo "Decompressing...\n";
    $gz = gzopen($gzFile, 'r');
    $out = fopen("$engineDir/$binary", 'w');
    while (!gzeof($gz)) fwrite($out, gzread($gz, 65536));
    gzclose($gz);
    fclose($out);
    unlink($gzFile);
    chmod("$engineDir/$binary", 0755);
    echo "Engine downloaded to $engineDir/$binary\n";
    echo "Size: " . filesize("$engineDir/$binary") . "\n";
} else {
    echo "Failed to download. Trying alternative URL...\n";
    unlink($gzFile);
    // Try alternative URL pattern
    $url2 = "https://binaries.prisma.sh/$commit/$version/$platform/$binary.gz";
    echo "URL2: $url2\n";
    $ch = curl_init($url2);
    $fp = fopen($gzFile, 'w');
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    fclose($fp);
    echo "HTTP: $httpCode, Size: " . filesize($gzFile) . "\n";
}
