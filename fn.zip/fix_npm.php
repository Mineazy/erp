<?php
set_time_limit(300);
$node = '/opt/cpanel/ea-nodejs20/bin/node';
$npm = '/opt/cpanel/ea-nodejs20/bin/npm';
$npx = '/opt/cpanel/ea-nodejs20/bin/npx';
$dir = __DIR__;

echo "Node: " . `$node -v 2>&1` . "\n";
echo "NPM: " . `$npm -v 2>&1` . "\n";

// Check if node_modules exists
if (!is_dir("$dir/node_modules")) {
    echo "node_modules missing, running npm install...\n";
    echo `cd $dir && $npm install --production --no-optional 2>&1` . "\n";
} else {
    echo "node_modules exists, checking prisma...\n";
}

// Regenerate Prisma client
if (is_dir("$dir/node_modules/@prisma/client")) {
    echo "Generating Prisma client...\n";
    echo `cd $dir && $npx prisma generate 2>&1` . "\n";
} else {
    echo "@prisma/client not found after install\n";
}
echo "Done.\n";
