
Object.defineProperty(exports, "__esModule", { value: true });

const {
  Decimal,
  objectEnumValues,
  makeStrictEnum,
  Public,
  getRuntime,
  skip
} = require('@prisma/client/runtime/index-browser.js')


const Prisma = {}

exports.Prisma = Prisma
exports.$Enums = {}

/**
 * Prisma Client JS version: 5.22.0
 * Query Engine version: 605197351a3c8bdd595af2d2a9bc3025bca48ea2
 */
Prisma.prismaVersion = {
  client: "5.22.0",
  engine: "605197351a3c8bdd595af2d2a9bc3025bca48ea2"
}

Prisma.PrismaClientKnownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientKnownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)};
Prisma.PrismaClientUnknownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientUnknownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientRustPanicError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientRustPanicError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientInitializationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientInitializationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientValidationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientValidationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.NotFoundError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`NotFoundError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.Decimal = Decimal

/**
 * Re-export of sql-template-tag
 */
Prisma.sql = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`sqltag is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.empty = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`empty is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.join = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`join is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.raw = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`raw is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.validator = Public.validator

/**
* Extensions
*/
Prisma.getExtensionContext = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.getExtensionContext is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.defineExtension = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.defineExtension is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}

/**
 * Shorthand utilities for JSON filtering
 */
Prisma.DbNull = objectEnumValues.instances.DbNull
Prisma.JsonNull = objectEnumValues.instances.JsonNull
Prisma.AnyNull = objectEnumValues.instances.AnyNull

Prisma.NullTypes = {
  DbNull: objectEnumValues.classes.DbNull,
  JsonNull: objectEnumValues.classes.JsonNull,
  AnyNull: objectEnumValues.classes.AnyNull
}



/**
 * Enums
 */

exports.Prisma.TransactionIsolationLevel = makeStrictEnum({
  ReadUncommitted: 'ReadUncommitted',
  ReadCommitted: 'ReadCommitted',
  RepeatableRead: 'RepeatableRead',
  Serializable: 'Serializable'
});

exports.Prisma.ErpChartOfAccountsScalarFieldEnum = {
  id: 'id',
  code: 'code',
  name: 'name',
  type: 'type',
  category: 'category',
  isHeader: 'isHeader',
  parentId: 'parentId',
  balance: 'balance',
  currency: 'currency',
  isActive: 'isActive',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ErpJournalEntryScalarFieldEnum = {
  id: 'id',
  entryNumber: 'entryNumber',
  description: 'description',
  entryDate: 'entryDate',
  period: 'period',
  status: 'status',
  postedAt: 'postedAt',
  postedBy: 'postedBy',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ErpJournalLineScalarFieldEnum = {
  id: 'id',
  entryId: 'entryId',
  accountId: 'accountId',
  description: 'description',
  debit: 'debit',
  credit: 'credit',
  currency: 'currency',
  createdAt: 'createdAt'
};

exports.Prisma.ErpAccountReceivableScalarFieldEnum = {
  id: 'id',
  invoiceNumber: 'invoiceNumber',
  customerId: 'customerId',
  customerName: 'customerName',
  invoiceDate: 'invoiceDate',
  dueDate: 'dueDate',
  amount: 'amount',
  paidAmount: 'paidAmount',
  balance: 'balance',
  status: 'status',
  currency: 'currency',
  description: 'description',
  journalEntryId: 'journalEntryId',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ErpAccountPayableScalarFieldEnum = {
  id: 'id',
  billNumber: 'billNumber',
  supplierId: 'supplierId',
  supplierName: 'supplierName',
  billDate: 'billDate',
  dueDate: 'dueDate',
  amount: 'amount',
  paidAmount: 'paidAmount',
  balance: 'balance',
  status: 'status',
  currency: 'currency',
  description: 'description',
  journalEntryId: 'journalEntryId',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ErpCashbookScalarFieldEnum = {
  id: 'id',
  entryNumber: 'entryNumber',
  entryDate: 'entryDate',
  type: 'type',
  accountId: 'accountId',
  description: 'description',
  amount: 'amount',
  currency: 'currency',
  reference: 'reference',
  status: 'status',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ErpProductScalarFieldEnum = {
  id: 'id',
  code: 'code',
  name: 'name',
  description: 'description',
  categoryId: 'categoryId',
  unit: 'unit',
  costPrice: 'costPrice',
  sellingPrice: 'sellingPrice',
  stock: 'stock',
  minStock: 'minStock',
  location: 'location',
  barcode: 'barcode',
  isActive: 'isActive',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ErpProductCategoryScalarFieldEnum = {
  id: 'id',
  name: 'name',
  parentId: 'parentId',
  createdAt: 'createdAt'
};

exports.Prisma.ErpSalesOrderScalarFieldEnum = {
  id: 'id',
  orderNumber: 'orderNumber',
  customerId: 'customerId',
  customerName: 'customerName',
  orderDate: 'orderDate',
  status: 'status',
  subtotal: 'subtotal',
  taxAmount: 'taxAmount',
  discount: 'discount',
  total: 'total',
  currency: 'currency',
  notes: 'notes',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ErpSalesOrderLineScalarFieldEnum = {
  id: 'id',
  orderId: 'orderId',
  productId: 'productId',
  productName: 'productName',
  quantity: 'quantity',
  unitPrice: 'unitPrice',
  total: 'total'
};

exports.Prisma.ErpPurchaseOrderScalarFieldEnum = {
  id: 'id',
  poNumber: 'poNumber',
  supplierId: 'supplierId',
  supplierName: 'supplierName',
  orderDate: 'orderDate',
  expectedDate: 'expectedDate',
  status: 'status',
  subtotal: 'subtotal',
  taxAmount: 'taxAmount',
  total: 'total',
  currency: 'currency',
  notes: 'notes',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ErpPurchaseOrderLineScalarFieldEnum = {
  id: 'id',
  poId: 'poId',
  productId: 'productId',
  productName: 'productName',
  quantity: 'quantity',
  unitPrice: 'unitPrice',
  total: 'total'
};

exports.Prisma.ErpCustomerScalarFieldEnum = {
  id: 'id',
  code: 'code',
  name: 'name',
  type: 'type',
  contactPerson: 'contactPerson',
  email: 'email',
  phone: 'phone',
  mobile: 'mobile',
  address: 'address',
  city: 'city',
  country: 'country',
  taxId: 'taxId',
  creditLimit: 'creditLimit',
  balance: 'balance',
  notes: 'notes',
  isActive: 'isActive',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ErpSupplierScalarFieldEnum = {
  id: 'id',
  code: 'code',
  name: 'name',
  contactPerson: 'contactPerson',
  email: 'email',
  phone: 'phone',
  address: 'address',
  city: 'city',
  country: 'country',
  taxId: 'taxId',
  paymentTerms: 'paymentTerms',
  balance: 'balance',
  notes: 'notes',
  isActive: 'isActive',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ErpPosSessionScalarFieldEnum = {
  id: 'id',
  sessionNumber: 'sessionNumber',
  openedAt: 'openedAt',
  closedAt: 'closedAt',
  status: 'status',
  openedBy: 'openedBy',
  closedBy: 'closedBy',
  openingBalance: 'openingBalance',
  closingBalance: 'closingBalance',
  totalSales: 'totalSales',
  totalRefunds: 'totalRefunds',
  notes: 'notes',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ErpPosTransactionScalarFieldEnum = {
  id: 'id',
  transactionNumber: 'transactionNumber',
  sessionId: 'sessionId',
  customerId: 'customerId',
  customerName: 'customerName',
  subtotal: 'subtotal',
  taxAmount: 'taxAmount',
  discount: 'discount',
  total: 'total',
  paidAmount: 'paidAmount',
  changeAmount: 'changeAmount',
  paymentMethod: 'paymentMethod',
  status: 'status',
  notes: 'notes',
  postedToJournal: 'postedToJournal',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ErpPosTransactionLineScalarFieldEnum = {
  id: 'id',
  transactionId: 'transactionId',
  productId: 'productId',
  productName: 'productName',
  quantity: 'quantity',
  unitPrice: 'unitPrice',
  total: 'total',
  createdAt: 'createdAt'
};

exports.Prisma.ErpPosPaymentScalarFieldEnum = {
  id: 'id',
  transactionId: 'transactionId',
  method: 'method',
  amount: 'amount',
  reference: 'reference',
  createdAt: 'createdAt'
};

exports.Prisma.ErpUserScalarFieldEnum = {
  id: 'id',
  email: 'email',
  password: 'password',
  name: 'name',
  role: 'role',
  isActive: 'isActive',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.SortOrder = {
  asc: 'asc',
  desc: 'desc'
};

exports.Prisma.NullsOrder = {
  first: 'first',
  last: 'last'
};


exports.Prisma.ModelName = {
  ErpChartOfAccounts: 'ErpChartOfAccounts',
  ErpJournalEntry: 'ErpJournalEntry',
  ErpJournalLine: 'ErpJournalLine',
  ErpAccountReceivable: 'ErpAccountReceivable',
  ErpAccountPayable: 'ErpAccountPayable',
  ErpCashbook: 'ErpCashbook',
  ErpProduct: 'ErpProduct',
  ErpProductCategory: 'ErpProductCategory',
  ErpSalesOrder: 'ErpSalesOrder',
  ErpSalesOrderLine: 'ErpSalesOrderLine',
  ErpPurchaseOrder: 'ErpPurchaseOrder',
  ErpPurchaseOrderLine: 'ErpPurchaseOrderLine',
  ErpCustomer: 'ErpCustomer',
  ErpSupplier: 'ErpSupplier',
  ErpPosSession: 'ErpPosSession',
  ErpPosTransaction: 'ErpPosTransaction',
  ErpPosTransactionLine: 'ErpPosTransactionLine',
  ErpPosPayment: 'ErpPosPayment',
  ErpUser: 'ErpUser'
};

/**
 * This is a stub Prisma Client that will error at runtime if called.
 */
class PrismaClient {
  constructor() {
    return new Proxy(this, {
      get(target, prop) {
        let message
        const runtime = getRuntime()
        if (runtime.isEdge) {
          message = `PrismaClient is not configured to run in ${runtime.prettyName}. In order to run Prisma Client on edge runtime, either:
- Use Prisma Accelerate: https://pris.ly/d/accelerate
- Use Driver Adapters: https://pris.ly/d/driver-adapters
`;
        } else {
          message = 'PrismaClient is unable to run in this browser environment, or has been bundled for the browser (running in `' + runtime.prettyName + '`).'
        }
        
        message += `
If this is unexpected, please open an issue: https://pris.ly/prisma-prisma-bug-report`

        throw new Error(message)
      }
    })
  }
}

exports.PrismaClient = PrismaClient

Object.assign(exports, Prisma)
