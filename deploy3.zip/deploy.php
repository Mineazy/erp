<?php
set_time_limit(300);
$target = __DIR__;

function rmrf($path) {
    if (is_dir($path)) {
        $files = array_diff(scandir($path), ['.', '..']);
        foreach ($files as $f) rmrf("$path/$f");
        rmdir($path);
    } elseif (file_exists($path) || is_link($path)) {
        unlink($path);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['zip'])) {
    $zip = $_FILES['zip'];
    if ($zip['error'] !== UPLOAD_ERR_OK) {
        die("Upload error code: " . $zip['error']);
    }
    echo "Received: " . number_format($zip['size']) . " bytes\n";

    $old = $target . '/.next';
    if (is_dir($old)) { rmrf($old); echo "Removed old .next\n"; }

    $junkDirs = ['server', 'static', 'chunks', 'node_modules'];
    foreach ($junkDirs as $d) {
        $p = "$target/$d";
        if (is_dir($p)) { rmrf($p); echo "Removed $d\n"; }
    }
    $junkFiles = ['app-build-manifest.json', 'build-manifest.json', 'images-manifest.json',
                  'react-loadable-manifest.json', 'trace', 'BUILD_ID',
                  'app-path-routes-manifest.json', 'prerender-manifest.json', 'routes-manifest.json',
                  'middleware-manifest.json', 'middleware-build-manifest.json', 'export-marker.json',
                  'server-reference-manifest.json', 'next-minimal.js', 'next-minimal.js.nft.json',
                  'next-config.json', 'typescript.json'];
    foreach ($junkFiles as $f) {
        $p = "$target/$f";
        if (file_exists($p)) { unlink($p); echo "Removed $f\n"; }
    }
    foreach (glob("$target/*") as $f) {
        if (!is_dir($f) && strpos(basename($f), '\\') !== false) { unlink($f); echo "Removed junk\n"; }
    }

    $tmpZip = $zip['tmp_name'];
    $za = new ZipArchive();
    $res = $za->open($tmpZip);
    if ($res !== true) { die("Failed to open zip (code: $res)"); }

    $count = 0;
    for ($i = 0; $i < $za->numFiles; $i++) {
        $name = $za->getNameIndex($i);
        $name = str_replace('\\', '/', $name);
        if (substr($name, -1) === '/') continue;

        $dest = $target . '/' . $name;
        $dir = dirname($dest);
        if (!is_dir($dir)) mkdir($dir, 0755, true);

        $content = $za->getFromIndex($i);
        file_put_contents($dest, $content);
        $count++;
    }
    $za->close();
    echo "Extracted $count files.\nDone.\n";
} else {
    echo '<form method="post" enctype="multipart/form-data">';
    echo '<input type="file" name="zip" />';
    echo '<input type="submit" value="Deploy" />';
    echo '</form>';
}
