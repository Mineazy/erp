<?php
set_time_limit(120);
$dir = __DIR__;
$engineDir = "$dir/node_modules/.prisma/client";
$version = '5.22.0-44.605197351a3c8bdd595af2d2a9bc3025bca48ea2';
$platform = 'rhel-openssl-1.1.x';  # RHEL 8 based on kernel

# Try Node-API engine (libquery_engine.so.node)
$binary = 'libquery_engine.so.node';
$url = "https://binaries.prisma.sh/all_commits/$version/$platform/$binary.gz";
echo "Downloading: $url\n";

$gzFile = "$engineDir/$binary.gz";
$fp = fopen($gzFile, 'w');
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
fclose($fp);
$size = filesize($gzFile);

if ($httpCode == 200 && $size > 1000) {
    echo "Downloaded ($size bytes). Decompressing...\n";
    $gz = gzopen($gzFile, 'r');
    $out = fopen("$engineDir/$binary", 'w');
    while (!gzeof($gz)) fwrite($out, gzread($gz, 65536));
    gzclose($gz); fclose($out);
    unlink($gzFile);
    chmod("$engineDir/$binary", 0755);
    echo "Engine ready: " . filesize("$engineDir/$binary") . " bytes\n";
} else {
    echo "Failed HTTP $httpCode, size $size\n";
    unlink($gzFile);
    # Try query-engine binary
    $binary2 = 'query-engine-rhel-openssl-1.1.x';
    $url2 = "https://binaries.prisma.sh/all_commits/$version/$platform/$binary2.gz";
    echo "Trying: $url2\n";
    $fp2 = fopen($gzFile, 'w');
    $ch2 = curl_init($url2);
    curl_setopt($ch2, CURLOPT_FILE, $fp2);
    curl_setopt($ch2, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch2, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch2);
    $httpCode2 = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
    curl_close($ch2);
    fclose($fp2);
    $size2 = filesize($gzFile);
    if ($httpCode2 == 200 && $size2 > 1000) {
        echo "Downloaded ($size2 bytes). Decompressing...\n";
        $gz2 = gzopen($gzFile, 'r');
        $out2 = fopen("$engineDir/query-engine", 'w');
        while (!gzeof($gz2)) fwrite($out2, gzread($gz2, 65536));
        gzclose($gz2); fclose($out2);
        unlink($gzFile);
        chmod("$engineDir/query-engine", 0755);
        echo "Engine ready: " . filesize("$engineDir/query-engine") . " bytes\n";
    } else {
        unlink($gzFile);
        echo "Failed HTTP $httpCode2, size $size2\n";
    }
}
