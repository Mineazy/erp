<?php $d=__DIR__."/tmp";if(!is_dir($d))mkdir($d,0755,true);touch($d."/restart.txt");echo"restarted";
