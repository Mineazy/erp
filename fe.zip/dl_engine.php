<?php
set_time_limit(60);
$dir = __DIR__;
$engineDir = "$dir/node_modules/.prisma/client";
$commit = '605197351a3c8bdd595af2d2a9bc3025bca48ea2';
$version = '5.22.0-44.605197351a3c8bdd595af2d2a9bc3025bca48ea2';
$platform = 'linux-openssl-1.1.x';

// Try different binary name patterns
$binaries = ['query-engine', 'libquery_engine.so.node', 'query_engine.so.node'];
$found = false;

foreach ($binaries as $binary) {
    $url = "https://binaries.prisma.sh/all_commits/$version/$commit/$platform/$binary.gz";
    echo "Trying: $url\n";
    $gzFile = "$engineDir/$binary.gz";
    $ch = curl_init($url);
    $fp = fopen($gzFile, 'w');
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    fclose($fp);
    $size = filesize($gzFile);
    echo "HTTP: $httpCode, Size: $size\n";
    if ($httpCode == 200 && $size > 1000) {
        echo "Found engine: $binary\n";
        // Decompress
        $gz = gzopen($gzFile, 'r');
        $out = fopen("$engineDir/$binary", 'w');
        while (!gzeof($gz)) fwrite($out, gzread($gz, 65536));
        gzclose($gz); fclose($out);
        unlink($gzFile);
        chmod("$engineDir/$binary", 0755);
        echo "Success: " . filesize("$engineDir/$binary") . " bytes\n";
        $found = true;
        break;
    } else {
        unlink($gzFile);
    }
}

if (!$found) {
    // Try without version in URL
    $url = "https://binaries.prisma.sh/$commit/$version/$platform/query-engine.gz";
    echo "Trying alternative: $url\n";
    $gzFile = "$engineDir/query-engine.gz";
    $ch = curl_init($url);
    $fp = fopen($gzFile, 'w');
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch); fclose($fp);
    $size = filesize($gzFile);
    echo "HTTP: $httpCode, Size: $size\n";
    if ($httpCode == 200 && $size > 1000) {
        echo "Found!\n";
        $gz = gzopen($gzFile, 'r');
        $out = fopen("$engineDir/query-engine", 'w');
        while (!gzeof($gz)) fwrite($out, gzread($gz, 65536));
        gzclose($gz); fclose($out);
        unlink($gzFile);
        chmod("$engineDir/query-engine", 0755);
        echo "Success: " . filesize("$engineDir/query-engine") . " bytes\n";
        $found = true;
    } else {
        unlink($gzFile);
    }
}

if (!$found) {
    echo "Could not find engine URL.\n";
}
